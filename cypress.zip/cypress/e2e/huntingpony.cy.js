describe('Тестирование Hunting Pony', function () {
    
    it('Проваливаюсь в оформление заказа на HuntingPony', function () {
        cy.visit('https://huntingpony.com/');
        cy.get('[data-index="7"] > .header__collections-controls > .header__collections-link').click();
        cy.get('.product-preview__title > a').click();
        cy.contains('В корзину').should('be.visible');
        cy.wait(5000)
        cy.get('.add-cart-counter__btn').trigger('mouseover').click();
        cy.wait(5000)
        cy.get('[data-add-cart-counter-plus=""]').trigger('mouseover').click();
        cy.wait(5000)
        cy.get('.add-cart-counter__detail-dop-text').trigger('mouseover').click();
        cy.get('.cart-controls > .button').click();
        cy.contains('Оформление заказа').should('be.visible');



       })
})